# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:08:26 2018

@author: SRanganath
"""
from Connections import WIDE_ORBIT_MASTER_CONNECT, WIDE_ORBIT_MASTER_QUERY
import pandas as pd
import datetime
master_data = pd.read_sql(WIDE_ORBIT_MASTER_QUERY, WIDE_ORBIT_MASTER_CONNECT)




'''
From Wide orbit to our database:

select * , datepart("ISO_WEEK" , full_date) as Air_week,
CASE WHEN
DATEPART(ISO_WEEK, [full_date]) > 50 AND
MONTH([full_date]) = 1 THEN YEAR([full_date]) - 1
WHEN DATEPART(ISO_WEEK, [full_date]) = 1 AND
MONTH([full_date]) = 12 THEN YEAR([full_date]) + 1
ELSE YEAR([full_date]) END AS Air_year,
datepart("ISO_WEEK", [Order Created]) as Order_week
, CASE WHEN DATEPART(ISO_WEEK, [ORDER CREATED]) > 50 AND
MONTH([ORDER CREATED]) = 1 THEN YEAR([ORDER CREATED]) - 1
WHEN DATEPART(ISO_WEEK, [ORDER CREATED]) = 1 AND
MONTH([ORDER CREATED]) = 12 THEN YEAR([ORDER CREATED]) + 1
ELSE YEAR([ORDER CREATED]) END AS OrderYear,
(([Length1]+[Length2])/1000.0/30.0) as booked_spots
FROM [wo_analytics_GTV01].[dbo].[vw_SpotRatingDV]
where [Station Call Letters] in ('KPNX', 'KUSA', 'WWL', 'WFAA', 'WVEC' ,
                                 'KARE','KHOU', 'WXIA', 'KING', 'KSDK',
                                 'WTSP' ,'WCNC','WKYC', 'KGW', 'WUSA' ,'KENS',
                                 'WTLV','KVUE','WCSH','KXTV','WGRZ','WFMY',
                                 'WBIR')
and  year(full_date) >= 2018;
'''