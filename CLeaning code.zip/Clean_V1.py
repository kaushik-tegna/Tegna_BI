"""
Created on Wed Jun 13 10:55:06 2018
@author: SRanganath
,,,"""
from Connections import WIDE_ORBIT_CONNECT, WIDE_ORBIT_QUERY
import pandas as pd
import numpy as np
import datetime
import re
import sqlalchemy
import urllib
# import time
# start = time.time()

# Connection String and Query to fetch  data

data = pd.read_sql(WIDE_ORBIT_QUERY, WIDE_ORBIT_CONNECT)
data = data.sort_values(by=['air_year', 'air_week', 'program_start_time'])

# date_correction

data['start_time_cleaned'] = [datetime.datetime.time(time) for time
                              in data['program_start_time']]
data['end_time_cleaned'] = [datetime.datetime.time(time) for time
                            in data['program_end_time']]

data['start_time_cleaned'] = datetime.datetime.time(data['program_start_time'])


# rearranging the cleaned columns

data = data[['market', 'Station_Name', 'daypart_name', 'invcode_name',
             'invcode_External_Id', 'break_code', 'full_date', 'order_number',
             'order_created', 'program_start_time', 'start_time_cleaned',
             'program_end_time', 'end_time_cleaned', 'potential_units',
             'spot_counts', 'spot_rating_key', 'affiliation', 'gross_revenue',
             'air_year', 'air_week', 'order_year', 'Order_week',
             'full_datetime', 'created_datetime', 'last_updated']]

# Treating null values, removing SP dayparts with olympics

SP_data = data[(data.daypart_name == 'SP')]

# Olympics only data
olympic_pattern = re.compile('.*(olympic).*', re.IGNORECASE)
Olympics_data = data[(data.daypart_name == 'SP') &
                     data.invcode_name.str.match(olympic_pattern)]

# null_df = data[data.program_start_time != data.program_start_time]

# Inventory_Unique = list((SP_data.invcode_name.unique()))

# Creating a dataframe with only sports data

Sports_data = SP_data[(~SP_data.invcode_name.str.match(olympic_pattern))]

# Identifying shows with missing years

# view = sp_df
Invcode_List = list(data.invcode_name.unique())

# Creating a dictionary with years data
years_dict = {}
for invcode_name in Invcode_List:
    temp = data[(data.invcode_name == invcode_name)]
    years_dict[invcode_name] = temp.air_year.unique()

del temp, invcode_name

# Determining the amount of historical data for time series
Current_Year = datetime.datetime.now().year
TS_Years = list(pd.Series(range((Current_Year-5), (1+Current_Year))))

# Looping through each value in the dictionary to check if its good for TS
Good_TS_data = []
Bad_TS_data = []


for key, value in years_dict.items():
    if (set(TS_Years) & set(value)) == set(TS_Years):
        Good_TS_data.append(key)
        # print(key, value, "Good")
    else:
        Bad_TS_data.append(key)
        # print(key, value, "Bad")

Fit_TS = data[data['invcode_name'].isin(Good_TS_data)]
Unfit_TS = data[data['invcode_name'].isin(Bad_TS_data)]

# check = list(Fit.invcode_name.unique())

fit_count = list(Fit_TS.invcode_name.unique())
unfit_count = list(Unfit_TS.invcode_name.unique())

Fit_TS.shape[0] + Unfit_TS.shape[0]

# Adding a new column to the fit and Unfit Df's

Fit_TS['Timeseries'] = 'Fit'
Unfit_TS['TimeSeries'] = 'Unfit'

# Group by object

a = list(['1','2','3'])
print(a)
b = list(['4','5','6'])
c = list(zip(a,b))
groups = Fit_TS.groupby(['market', 'Station_Name', 'daypart_name',
                         'invcode_name', 'air_week'])['air_year'].unique()
test_df = groups.apply(list)

test_df = test_df.to_frame().reset_index()

test_df.air_year.dtype

test_df['air_year'] = test_df['air_year'].apply(lambda x: np.array(x))

# Merging the data frame with the groupby object

join = pd.merge(test_df, Fit_TS,  how='left',
                on=['market', 'Station_Name', 'daypart_name',
                    'invcode_name', 'air_week'])
view = data.head(10000)

connection_string = 'DRIVER={SQL SERVER}; server=172.21.128.193; database=Wide_Orbit;uid=etl_user_prod;pwd=T@gna2018'
engine_parameters =urllib.parse.quote_plus(connection_string)
database_engine = sqlalchemy.create_engine("mssql+pyodbc:///?odbc_connect=%s" % engine_parameters)

view.to_sql('[Wide_orbit].[dbo].[Buyer_Demand_Forecast_Input_Flagged]', database_engine)

engine = sqlalchemy.create_engine('''mssql://etl_user_prod:'T@gna2018'@172.21.128.193/Wide_Orbit''',echo=False)
engine = sqlalchemy.create_engine('mssql+pyodbc://etl_user_prod:"T@gna2018"@172.21.128.193')


view.to_sql('Buyer_Demand_Forecast_Input_Flagged', con=database_engine, if_exists='append')
