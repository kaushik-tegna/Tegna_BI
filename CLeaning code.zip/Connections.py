# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 16:20:43 2018
File_Name: Connection Strings
@author: Kaushik
"""
import pyodbc
WIDE_ORBIT_CONNECT = pyodbc.connect("""Driver={SQL Server Native Client 11.0};
                      Server=172.21.128.193; ""Database=Wide_Orbit;
                      UID=etl_user_prod; pwd=T@gna2018;""")

WIDE_ORBIT_QUERY = """SELECT * FROM
                     [Wide_Orbit].[dbo].[buyer_demand_fcst_input_new2]
                     where [Market] like '%ATlanta%'"""
                     
      

VALIDATION_QUERY = """Select Distinct(Inventory_code) FROM
                     [Wide_Orbit].[dbo].[price_grid_batch1]
                     WHERE [wo_market] like '%Atlanta%'"""
                     
