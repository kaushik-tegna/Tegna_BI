# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 10:41:50 2018

@author: SRanganath
"""
import Cleaning_V2

# Calculating the grouped median

Median_group = data.groupby(['market', 'station_name',
                             'daypart_name', 'invcode_name',
                             'air_week', 'air_year'])['spot_counts'].median()
Median_group = Median_group.reset_index()
Median_data = pd.merge(Median_group, data, how='left',
                       on=['market', 'station_name', 'daypart_name',
                           'invcode_name', 'air_week', 'air_year'])
Median_data = Median_data.rename(index=str,
                                 columns={'spot_counts_y': 'spot_counts',
                                          'spot_counts_x': 'spot_median'})
del Median_group


# Calculating the Median absolute deviation

mad_group = Median_data.groupby(['market', 'station_name',
                                 'daypart_name', 'invcode_name',
                                 'air_week', 'air_year'])['spot_counts'].mad()
mad_group = mad_group.reset_index()

Mad_data = pd.merge(mad_group, Median_data, how='left',
                    on=['market', 'station_name', 'daypart_name',
                        'invcode_name', 'air_week', 'air_year'])
Mad_data = Mad_data.rename(index=str,
                           columns={'spot_counts_y': 'spot_counts',
                                    'spot_counts_x': 'spot_mad'})

view = Mad_data.head(1000)
view = Median_data
View1 = Mad_data[['spot_counts', 'spot_mad', 'spot_median']]

#['spot_counts'].mad()
# Creating a dictionary with multiple values and function
test_group = view.groupby(['market', 'station_name',
                                 'daypart_name', 'invcode_name',
                                 'air_week', 'air_year']).agg({'spot_counts':['median', 'mad']})
test_group = test_group.reset_index()

test_data = pd.merge(test_group, view, how='left',
                    on=['market', 'station_name', 'daypart_name',
                        'invcode_name', 'air_week', 'air_year'])

view2 = test_data.head(1000)

list(test_group)