# -*- coding: utf-8 -*-
"""
Created on Fri Jul  6 13:38:08 2018

@author: SRanganath
"""
from Cleaning_V2 import Bad_Data, final_table
# , Good_Data, final_table, normal_pile

data = Bad_Data.groupby(['market', 'station_name', 'daypart_name',
                         'invcode_name', 'order_year', 
                         'order_week'])['spot_counts'].sum()
data = data.reset_index()


# plotting Unfit_TS and good count

df = Bad_Data[Bad_Data['spot_flag'] == 'good']

bad_list  = list(df['invcode_name'].unique())

sample = data[data['invcode_name'] == 'Local News @ 11p Su']

# plotting Fit_TS and bad spot_count

# plotting Unfit_TS and bad spot_count

# plotting Fit_TS and good spot_count ---- IDEAL


view = Bad_Data[Bad_Data['invcode_name'] == 'Local News @ 11p Su']




['market',
 'station_name',
 'daypart_name',
 'invcode_name',
 'air_week',
 'air_year',
 'invcode_external_id',
 'break_code',
 'full_date',
 'order_number',
 'order_created',
 'program_start_time',
 'start_time_cleaned',
 'program_end_time',
 'end_time_cleaned',
 'potential_units',
 'spot_counts',
 'spot_rating_key',
 'affiliation',
 'gross_revenue',
 'order_year',
 'order_week',
 'full_datetime',
 'created_datetime',
 'last_updated',
 'time_series_flag',
 'spot_flag',
 'sport_olympic_flag']