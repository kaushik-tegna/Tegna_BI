import pandas
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import mpld3
import hdbscan

if __name__ == '__main__':
    # data = pandas.read_csv('data_binary.csv')
    advertiser_labels = pandas.read_csv('data_refactored.csv')
    # advertiser = advertiser_labels['inventory_code'].tolist()
    # REMOVE ADVERTISER
    # ALSO DROP SUB CATEGORY

    # Notes: Throwing in everything and using hdbscan does not give sensible clusters. Lets use a forward approach
    # to see what we can figure out using our DOMAIN KNOWLEDGE>
    # Start with just daypart.

    # Daypart and inventory code gives very sensible clusters.
    # Now lets add the order demographic.
    # adding order demographic makes things mess up

    # LEAVE OUT SUBCATEGORY
    # Dont like priority code

    # sensible clusters but lots of noise
    # subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code']]

    # This setting is even better
    # subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code', 'booked_spots']]
    # THIS IS THE CURRENT BEST SET
    # subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code', 'booked_spots']]

    subset = advertiser_labels[['Break_code', 'Order Demo', 'inventory_code']]
    dummies = pandas.get_dummies(subset)
    # advertiser = advertiser_labels['Advertiser'].tolist()
    # inventory_codes = data['inventory_code'].tolist()
    daypart = advertiser_labels['Daypart'].tolist()
    quarter = advertiser_labels['Order Demo'].tolist()
    length = advertiser_labels['Break_code']

    pair = list(zip(daypart, quarter, length))

    labels = hdbscan.HDBSCAN(metric='hamming').fit_predict(dummies)

    # lables is an array of the labels

    dummies['cluster'] = labels
    advertiser_labels['cluster'] = labels
    advertiser_labels.to_csv('cluster_results.csv')
    clustered = (labels >= 0)
