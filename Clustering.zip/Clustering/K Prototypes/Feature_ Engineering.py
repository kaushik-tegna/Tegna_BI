import pandas as pd
import pyodbc


WIDE_ORBIT_QUERY = """
                     SELECT [Advertiser],[Advertiser Zipcode] as 'Zipcode',
                     [Daypart (ordered)] as'Daypart',[full_date],
                     [Product Category] as 'Category',[Product Sub-Category]
                     as 'sub-category',[Length1],[Length2]
                     FROM [Wide_Orbit].[dbo].[fact_spot_rating_dv]
                     where year([full_date])=2017 and [Station Call Letters]='WFAA'
                     """

WIDE_ORBIT_CONNECT = pyodbc.connect("""Driver={SQL Server Native Client 11.0};
                                    Server=172.21.128.193; Database=Wide_Orbit;
                                    UID=etl_user_prod; pwd=T@gna2018;""")

df = pd.read_sql(WIDE_ORBIT_QUERY, WIDE_ORBIT_CONNECT)
df['full_date'] = pd.to_datetime(df['full_date'])
df['Qtr'] = pd.to_datetime(df.full_date).dt.quarter
df['Qtr'] = df['Qtr'].apply(str)

advertisers = df.groupby(['Advertiser'])
df2 = advertisers['Qtr'].value_counts()
df2 = df2.to_frame()
df2.rename(columns={'Qtr': 'Qtr_count'}, inplace=True)
df2.reset_index(inplace=True)

view = df2.head(100)

df.drop(columns=['Length1', 'Length2'], inplace=True)
df2.drop(columns=['Qtr_count'], inplace=True)

def spot_length(row):
    spot_sum = ((row['Length1'] + row['Length2'])/1000)
    result = (spot_sum/30)
    return result


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='Qtr', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row

df['Spot_Length'] = df.apply(spot_length, axis=1)

df.dtypes

df.drop(columns=['Length1', 'Length2'], inplace=True)

grp = df2.groupby(['Advertiser'])
quarter = grp.apply(sort_list)
quarter.drop(columns=['index','Advertiser'], inplace=True)
quarter

df['Spot_Length'] = df['Spot_Length'].apply(str)


advertiser = df.groupby(['Advertiser'])
df4 = advertiser['Spot_Length'].value_counts()
df4 = df4.to_frame()
df4.rename(columns={'Spot_Length': 'Spot_count'}, inplace=True)
df4.reset_index(inplace=True)


grp = df4.groupby(['Advertiser'])
Spot = grp.apply(sort_list)
Spot.drop(columns=['index', 'Advertiser', ])


list(df4)

def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='Spot_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


grp = df4.groupby(['Advertiser'])
df3 = advertisers['Qtr'].value_counts()
df3 = df3.to_frame()
df3.rename(columns={'Qtr': 'Qtr_count'}, inplace=True)
df3.reset_index(inplace=True)

Spot = grp.apply(sort_list)

grp = df3.groupby(['Advertiser'])


advertisers = df.groupby(['Advertiser'])
df4 = advertisers['Spot_Length'].value_counts()
df3 = df3.to_frame()
df3.rename(columns={'Qtr': 'Qtr_count'}, inplace=True)
df3.reset_index(inplace=True)


Spot.drop(columns=['index', 'Spot_count', 'Advertiser'], inplace=True)
Spot.reset_index(inplace=True)
Spot.drop(columns='level_1', inplace=True)


grp = df3.groupby(['Advertiser'])

data = df[['Advertiser', 'Category']]

data.drop_duplicates(subset=['Advertiser'], inplace=True)

advertiser = df.groupby(['Advertiser'])
df3 = advertiser['Daypart'].value_counts()
df3 = df3.to_frame()
df3.rename(columns={'Daypart': 'Daypart_count'}, inplace=True)
df3.reset_index(inplace=True)
grp = df3.groupby(['Advertiser'])


Daypart = grp.apply(sort_list)

Daypart.drop(columns=['index', 'Advertiser', 'Daypart_count'], inplace=True)
Daypart.reset_index(inplace=True)
Daypart.drop(columns=['level_1'], inplace=True)

Qtr = grp.apply(sort_list)
Qtr.drop(columns=[ 'index', 'Advertiser','Qtr_count'], inplace=True)
Qtr.reset_index(inplace=True)
Qtr.drop(columns=['level_1'], inplace=True)
df.dtypes
df['Length1'] = str(df['Length1'])
df['Length2'] = str(df['Length2'])
df3 = check[['Advertiser', 'Daypart (ordered)']]
df3.reset_index(inplace=True)
data = df[['Advertiser', 'Advertiser Zipcode', 'Product Sub-Category',
           'Length1', 'Length2', 'Qtr']]


Qtr.drop(columns=['index','Advertiser','Qtr_count'], inplace=True)
Qtr.reset_index(inplace=True)
Qtr.drop(columns=['level_1'],inplace=True)

Spot.drop(columns=['index','Advertiser','Spot_count'], inplace=True)
Spot.reset_index(inplace=True)
Spot.drop(columns=['level_1'],inplace=True)

fin_data.dropna(inplace=True)


advertiser = df.groupby([''])

fin_data = pd.merge(quarter, Spot, on='Advertiser', how='left')
fin_data = pd.merge(fin_data, Daypart, on='Advertiser', how='left')
fin_data = pd.merge(fin_data, data, on='Advertiser', how='left')

fin_data.dtypes
fin_data['Spot_Length'] = fin_data['Spot_Length'].apply(str)
data_fin = fin_data.drop(columns=['Advertiser'])

data_fin = pd.get_dummies(data_fin)


fin_data.to_csv('labels_new.csv', index=False)
data_fin.to_csv('data_binary.csv', index=False)
