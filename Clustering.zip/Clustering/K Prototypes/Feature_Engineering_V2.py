# -*- coding: utf-8 -*-
"""
Created on Thu Aug  2 14:04:23 2018

@author: SRanganath
"""

import time
import pandas as pd
import pyodbc
start = time.time()

WIDE_ORBIT_QUERY = """SELECT [Station Call Letters] as 'station',
                     [Inventory Code (placed)] as 'inventory_code',
                     [Advertiser] as 'advertiser',
                     [Daypart (placed)] as 'daypart',
                     [program_start_time] as 'start_time',
                     [program_end_time] as 'end_time',
                     [Order Demo] as 'order_demo',
                     [Break Code] as 'break_code',
                     [Priority Code] as 'priority_code',
                     [Product Sub-Category] as 'sub_category',
                     [booked_spots]
                     FROM [Wide_Orbit].[dbo].[fact_spot_rating_dv]
                     where year([full_date])=2017
                     and [Station Call Letters]='WFAA'
                     and [Product Category] = 'Retail'"""

WIDE_ORBIT_CONNECT = pyodbc.connect("""Driver={SQL Server Native Client 11.0};
                                    Server=172.21.128.193; Database=Wide_Orbit;
                                    UID=etl_user_prod; pwd=T@gna2018;""")


REVENUE_QUERY = """
                SELECT [Advertiser] as 'advertiser',
                SUM([Gross Revenue]) as 'gross_revenue'
                FROM [Wide_Orbit].[dbo].[fact_spot_rating_dv]
                where year([full_date])=2017 and [Station Call Letters]='WFAA'
                and [Product Category] = 'Retail'  and [Gross Revenue]>0
                group by [Advertiser] order by gross_revenue
                """
revenue_df = pd.read_sql(REVENUE_QUERY, WIDE_ORBIT_CONNECT)

data = pd.read_sql(WIDE_ORBIT_QUERY, WIDE_ORBIT_CONNECT)
data.dropna(inplace=True)

# data.drop(columns=['station', 'break_code'], inplace=True)

# We need to group all the columns ad find values that have
# the highest numebr of occurences i.e MODe of all the values


# 1. Grouping stuff for Inventory Code

adv_grp = data.groupby(['advertiser'])

inv_df = adv_grp['inventory_code'].value_counts()
inv_df = inv_df.to_frame()
inv_df.rename(columns={'inventory_code': 'inv_count'}, inplace=True)
inv_df.reset_index(inplace=True)

grp = inv_df.groupby(['advertiser'])

data['booked_spots'] = data['booked_spots'].apply(str)
data.dtypes


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='inv_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


inv_df = grp.apply(sort_list)
inv_df.drop(columns=['index', 'inv_count', 'advertiser'], inplace=True)
inv_df.reset_index(inplace=True)
inv_df.drop(columns=['level_1'], inplace=True)


# 2. Grouping Stuff for Daypart

adv_grp = data.groupby(['advertiser'])
dp_df = adv_grp['daypart'].value_counts()
dp_df = dp_df.to_frame()
dp_df.rename(columns={'daypart': 'daypart_count'}, inplace=True)
dp_df.reset_index(inplace=True)

grp = dp_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='daypart_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


dp_df = grp.apply(sort_list)


dp_df.drop(columns=['index', 'advertiser', 'daypart_count'], inplace=True)
dp_df.reset_index(inplace=True)
dp_df.drop(columns=['level_1'], inplace=True)


# 3. Grouping Stuff for Order Demo

adv_grp = data.groupby(['advertiser'])
demo_df = adv_grp['order_demo'].value_counts()
demo_df = demo_df.to_frame()
demo_df.rename(columns={'order_demo': 'demo_count'}, inplace=True)
demo_df.reset_index(inplace=True)

grp = demo_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='demo_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


demo_df = grp.apply(sort_list)


demo_df.drop(columns=['index', 'advertiser', 'demo_count'], inplace=True)
demo_df.reset_index(inplace=True)
demo_df.drop(columns=['level_1'], inplace=True)


# 4. Grouping Stuff for Break Code

adv_grp = data.groupby(['advertiser'])
break_df = adv_grp['break_code'].value_counts()
break_df = break_df.to_frame()
break_df.rename(columns={'break_code': 'break_count'}, inplace=True)
break_df.reset_index(inplace=True)

grp = break_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='break_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


break_df = grp.apply(sort_list)


break_df.drop(columns=['index', 'advertiser', 'break_count'], inplace=True)
break_df.reset_index(inplace=True)
break_df.drop(columns=['level_1'], inplace=True)

# 4. Grouping Stuff for Priority Code

adv_grp = data.groupby(['advertiser'])
priority_df = adv_grp['priority_code'].value_counts()
priority_df = priority_df.to_frame()
priority_df.rename(columns={'priority_code': 'priority_count'}, inplace=True)
priority_df.reset_index(inplace=True)

grp = priority_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='priority_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


priority_df = grp.apply(sort_list)


priority_df.drop(columns=['index', 'advertiser', 'priority_count'],
                 inplace=True)
priority_df.reset_index(inplace=True)
priority_df.drop(columns=['level_1'], inplace=True)


# 5. Grouping Stuff for Sub_Category

adv_grp = data.groupby(['advertiser'])
subcat_df = adv_grp['sub_category'].value_counts()
subcat_df = subcat_df.to_frame()
subcat_df.rename(columns={'sub_category': 'subcat_count'}, inplace=True)
subcat_df.reset_index(inplace=True)

grp = subcat_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='subcat_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


subcat_df = grp.apply(sort_list)


subcat_df.drop(columns=['index', 'advertiser', 'subcat_count'],
               inplace=True)
subcat_df.reset_index(inplace=True)
subcat_df.drop(columns=['level_1'], inplace=True)

# 6. Grouping Stuff for booked_spots

adv_grp = data.groupby(['advertiser'])
spot_df = adv_grp['booked_spots'].value_counts()
spot_df = spot_df.to_frame()
spot_df.rename(columns={'booked_spots': 'spot_count'}, inplace=True)
spot_df.reset_index(inplace=True)

grp = spot_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='spot_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


spot_df = grp.apply(sort_list)


spot_df.drop(columns=['index', 'advertiser', 'spot_count'],
             inplace=True)
spot_df.reset_index(inplace=True)
spot_df.drop(columns=['level_1'], inplace=True)


# 7. Grouping Stuff for start_time

adv_grp = data.groupby(['advertiser'])
start_df = adv_grp['start_time'].value_counts()
start_df = start_df.to_frame()
start_df.rename(columns={'start_time': 'start_count'}, inplace=True)
start_df.reset_index(inplace=True)

grp = start_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='start_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


start_df = grp.apply(sort_list)


start_df.drop(columns=['index', 'advertiser', 'start_count'],
              inplace=True)
start_df.reset_index(inplace=True)
start_df.drop(columns=['level_1'], inplace=True)

# 8. Grouping Stuff for end_time

adv_grp = data.groupby(['advertiser'])
end_df = adv_grp['end_time'].value_counts()
end_df = end_df.to_frame()
end_df.rename(columns={'end_time': 'end_count'}, inplace=True)
end_df.reset_index(inplace=True)

grp = end_df.groupby(['advertiser'])


def sort_list(X):
    y = X.reset_index()
    y.sort_values(by='end_count', ascending=False, inplace=True)
    first_row = y.head(1)
    return first_row


end_df = grp.apply(sort_list)


end_df.drop(columns=['index', 'advertiser', 'end_count'],
            inplace=True)
end_df.reset_index(inplace=True)
end_df.drop(columns=['level_1'], inplace=True)


# Merging all data frames on Advertiser to get final DF

final_data = pd.merge(break_df, demo_df, on='advertiser', how='left')
final_data = pd.merge(final_data, dp_df, on='advertiser', how='left')
final_data = pd.merge(final_data, inv_df, on='advertiser', how='left')
final_data = pd.merge(final_data, priority_df, on='advertiser', how='left')
final_data = pd.merge(final_data, spot_df, on='advertiser', how='left')
final_data = pd.merge(final_data, subcat_df, on='advertiser', how='left')
final_data = pd.merge(final_data, start_df, on='advertiser', how='left')
final_data = pd.merge(final_data, end_df, on='advertiser', how='left')
final_data = pd.merge(final_data, revenue_df, on='advertiser', how='left')

final_data.to_csv('dallas_retail_2017.csv', index=False)

end = time.time()
print(end-start)
del end, start, break_df, demo_df, dp_df, inv_df, revenue_df
del priority_df, spot_df, subcat_df, start_df, end_df
