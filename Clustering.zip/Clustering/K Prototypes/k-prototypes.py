# -*- coding: utf-8 -*-
"""
Created on Fri Jul 27 11:33:33 2018

@author: SRanganath
"""
# Multi line binarizer for fact_spot_rating_dv

import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
import pyodbc

"""
mlb = MultiLabelBinarizer()
df = df.join(pd.DataFrame(mlb.fit_transform(df.pop('Col3')),
                          columns=mlb.classes_,
                          index=df.index))

df_out = df.assign(**pd.get_dummies(df.Col3.apply(lambda x:pd.Series(x)).stack().reset_index(level=1,drop=True)).sum(level=0))
"""

WIDE_ORBIT_CONNECT = pyodbc.connect("""Driver={SQL Server Native Client 11.0};
                      Server=172.21.128.193; Database=Wide_Orbit;
                      UID=etl_user_prod; pwd=T@gna2018;""")

WIDE_ORBIT_QUERY = """SELECT [Station Call Letters] as station_call_letters, [Advertiser] as advertiser,[Order #] as order_number,
[Inventory Code (ordered)] as inventory_code, [Daypart (ordered)] as daypart, [Gross Revenue] as revenue, 
[Product Category] as category, [Product Sub-Category] as subcategory, [Length1], [Length2]  from  [Wide_Orbit].[dbo].[fact_spot_rating_dv] where year(full_date) = 2017 and [Station Call Letters] = 'WFAA'
and [Product Category] = 'Retail' and [Gross Revenue] > 0 and [Inventory Code (ordered)] is not NULL
And [Order # ] is not NULL"""
            
df = pd.read_sql(WIDE_ORBIT_QUERY, WIDE_ORBIT_CONNECT )

# grouping stuff  for Unique Inventory Code

grp_inv = df.groupby(['advertiser', 'order_number'])['inventory_code'].unique()
grp_inv = grp_inv.apply(list).reset_index()

mlb = MultiLabelBinarizer()
binarized_df = grp_inv.join(pd.DataFrame(mlb.fit_transform(grp_inv.pop('inventory_code')),
                                         columns=mlb.classes_,
                                         index=grp_inv.index))
binarized_categories = pd.get_dummies(binarized_df,columns=['advertiser'])

df2 = df[['advertiser', 'order_number']]

binarized_categories.to_csv('Binarized.csv', index=False)

cluster_df = pd.merge(df2,binarized_categories, how='left', on='order_number')

data = cluster_df.drop(columns='order_number', axis=1)

data.to_csv('cluster_data.csv')

grp_inv.to_csv('label_df.csv')


clients = list(df.advertiser.unique())
