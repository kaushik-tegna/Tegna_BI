import pandas
from kmodes import kmodes
data = pandas.read_csv('data.csv')
labels = pandas.read_csv('labels.csv')
km = kmodes.KModes(n_clusters=5, init='Huang',  verbose=2)
clusters = km.fit_predict(data)
labels['clusters'] = clusters
# This is the bit that gives you the cluster centroids
print(km.cluster_centroids_)
labels['centroid'] = km.cluster_centroids_
#centroids = pandas.DataFrame({'centroids': km.cluster_centroids_, 'cluster_number': clusters})
#centroids.to_csv('cluster_centroids.csv')
labels.to_csv('inv_clustering.csv')
