from umap import UMAP
import pandas
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import mpld3
import hdbscan

def draw_umap(n_neighbors=30, min_dist=0.1, n_components=2, metric='jaccard', title=''):
    fit = umap.UMAP(
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        n_components=n_components,
        metric=metric
    )
    u = fit.fit_transform(data);
    fig = plt.figure()
    if n_components == 1:
        ax = fig.add_subplot(111)
        ax.scatter(u[:,0], range(len(u)), c=data)
    if n_components == 2:
        ax = fig.add_subplot(111)
        ax.scatter(u[:,0], u[:,1], c=data)
    if n_components == 3:
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(u[:,0], u[:,1], u[:,2], s=5)
    plt.title(title, fontsize=18)
    plt.show()




if __name__ == '__main__':

    data = pandas.read_csv('data.csv')
    advertiser_labels = pandas.read_csv('labels.csv')
    #advertiser = advertiser_labels['inventory_code'].tolist()
    #REMOVE ADVERTISER
    #subset = advertiser_labels[['sub-category']]
    #dummies = pandas.get_dummies(subset)
    #advertiser = advertiser_labels['Advertiser'].tolist()
    #inventory_codes = data['inventory_code'].tolist()
    daypart = advertiser_labels['Daypart'].tolist()
    #quarter = advertiser_labels['Spot_Length'].tolist()


   # pair = list(zip(advertiser,daypart, quarter))









    #clusters = pandas.read_csv('inv_clustering.csv')
    #labels = clusters['clusters']
    #dummies = pandas.get_dummies(subset)
    #target = clusters['clusters'].values
    #cmap = plt.get_cmap('viridis')
    #names = subset['advertiser'].unique().tolist()









    # WE NEED TO COLOR BY DIFFERENT SHIT

    # ARE MULTIPLE ADVERTISERS IN THE SAME GROUP
    # MAYBE JUST CLUSTER BASED ON NOT EVERYTHING EVER HUH
    # This gives cool results with clusters = 4
    embedding = umap.UMAP( min_dist=0.0, n_neighbors=5, metric='hamming').fit_transform(data)

    #color_dict = { '0':'red', '1':'blue', '2':'black', '3':'green'}
    # now i have to plot the shit
    #df = pandas.DataFrame(embedding, columns=('x', 'y'))
    #df['class'] = pandas.Series([str(x) for x in target], dtype="category")
    fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
    #scatter = ax.scatter(x=list(df['x']), y=list(df['y']),  s=5)
    #ax.set_title("Scatter Plot (with tooltips!)", size=20)
    #mpld3.show()



    #labels = hdbscan.HDBSCAN(
    #).fit_predict(embedding)

    #clustered = (labels >= 0)
    #scatter_2 = ax.scatter(embedding[clustered, 0],
    ##            embedding[clustered, 1],
     #           c=labels[clustered],
     #           s=.01,
     #           cmap='Spectral')
    #tooltip = mpld3.plugins.PointLabelTooltip(scatter_2, labels=daypart)
    #mpld3.plugins.connect(fig, tooltip)
    #mpld3.show()
    #print(labels.shape)

    draw_umap(n_components=3, title='n_components = 3')
