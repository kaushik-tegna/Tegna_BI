import umap
import pandas 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import mpld3
import hdbscan

if __name__ == '__main__':

    #data = pandas.read_csv('data_binary.csv')
    advertiser_labels = pandas.read_csv('dallas_retail_2017.csv')
    #names = pandas.read_csv('labels_new.csv')
    # PUT IN THE ADVERTISER
    #advertiser = advertiser_labels['inventory_code'].tolist()
    #REMOVE ADVERTISER
    # ALSO DROP SUB CATEGORY
    # THE NEXT STEP IS TO ADD THE MONEY
    # ADD IN THE NIELSEN DEMOGRAPHICS
    #dvertiser_names = names['Advertiser'].tolist()



     # # WHAT EACH CLUSTER IS WORTH
    # AVERAGE UNIT RATE
    # # THE EFFECTIVE UNIT RATE AS WELL
    # DO AS MUCH AS YOU CAN
    # INTENDED AUDIENCE MIGHT NOT HAVE VERY MANY THINGS
    # YOU HAVE TO TWEak THE TIME COMPONENT PROPERLY, SEE HOW IT CHANGES OVER TIME
    # PATCH IN THE NIELSEN INFORMATION


    # DO NOT CLUSTER BY ALL OF THESE THINGS JUST TACK IT ONTO THE CLUSTER RESULTS


    # rank the audiences FIRST SECOND AND THIRD AUDIENCE DEMOGRAPHICS


    #

    # Notes: Throwing in everything and using hdbscan does not give sensible clusters. Lets use a forward approach
    # to see what we can figure out using our DOMAIN KNOWLEDGE>
    # Start with just daypart.

    # Daypart and inventory code gives very sensible clusters.
    # Now lets add the order demographic.
    # adding order demographic makes things mess up



    # LEAVE OUT SUBCATEGORY
    # Dont like priority code


    # sensible clusters but lots of noise
    #subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code']]



    # This setting is even better
    #subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code', 'booked_spots']]
    # THIS IS THE CURRENT BEST SET
    subset = advertiser_labels[['Daypart', 'Order Demo', 'Break_code', 'booked_spots']]
    dummies = pandas.get_dummies(subset)
    #advertiser = advertiser_labels['Advertiser'].tolist()
    #inventory_codes = data['inventory_code'].tolist()
    daypart = advertiser_labels['Daypart'].tolist()
    quarter = advertiser_labels['Order Demo'].tolist()
    length = advertiser_labels['Break_code']

    labels = hdbscan.HDBSCAN(metric='hamming').fit_predict(dummies)
    # lables is an array of the labels

    dummies['cluster'] = labels
    advertiser_labels['cluster'] = labels
    target = advertiser_labels['cluster'].tolist()
    # advertiser_labels['advertiser'] = advertiser_names
    advertiser_labels.to_csv('cluster_results.csv')
    pair = target
    print(pair)

    embedding = umap.UMAP( metric='hamming', n_neighbors=5).fit_transform(dummies)

    # color_dict = { '0':'red', '1':'blue', '2':'black', '3':'green'}
    # now i have to plot the shit
    # df = pandas.DataFrame(embedding, columns=('x', 'y'))
    # df['class'] = pandas.Series([str(x) for x in target], dtype="category")
    fig, ax = plt.subplots(subplot_kw=dict(facecolor='#EEEEEE'))
    df = pandas.DataFrame(embedding, columns=('x', 'y'))
    df['cluster'] = pandas.Series([str(x) for x in target], dtype="category")
    fig, ax = plt.subplots(subplot_kw=dict(facecolor='#EEEEEE'))
    scatter = ax.scatter(x=pandas.Series(df['x']).to_json(orient='values'), y=pandas.Series(df['y']).to_json(orient='values'),
                         c=pandas.Series(df['cluster']).to_json(orient='values'),  s=2)
    tooltip = mpld3.plugins.PointLabelTooltip(scatter, labels=pair)
    mpld3.plugins.connect(fig, tooltip)
    ax.set_title("Retail Advertiser Segmentation", size=20)
    mpld3.show()




