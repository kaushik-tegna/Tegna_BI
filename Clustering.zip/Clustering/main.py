import pandas
import pyodbc
from kmodes import kmodes
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import numpy
from sklearn.manifold import TSNE

from kmodes.kprototypes import KPrototypes

#database_connection = pyodbc.connect('DRIVER={SQL Server};server=172.21.128.193;database=Wide_Orbit;uid=etl_user_prod;pwd=T@gna2018')


sql_query = " SELECT [Station Call Letters] as station_call_letters, [Advertiser] as advertiser, [Agency] as agency," \
            " [Inventory Code (ordered)] as inventory_code, [Daypart (ordered)] as daypart, [Gross Revenue] as revenue, " \
            "[Product Category] as category, [Product Sub-Category] as subcategory, [Length1], [Length2]  from  [Wide_Orbit].[dbo].[fact_spot_rating_dv] where year(full_date) = 2017 and [Station Call Letters] = 'WFAA'" \
            "and [Product Category] = 'Retail' and [Gross Revenue] > 0 and [Inventory Code (ordered)] is not NULL"

#spot_data = pandas.read_sql_query(sql_query, database_connection)
#spot_data.dropna(inplace=True)
#spot_data.to_csv('spot_data.csv')
#engineer time features from the full_date
# its probably easiest to do this in sql, so maybe do it above
spot_data = pandas.read_csv('spot_data.csv')
shit = spot_data[['advertiser',  'daypart', 'inventory_code']]
categorical = pandas.get_dummies(shit)


# Lets see how many distinct retail people there are

#concat = pandas.merge(categorical,numeric, how='inner', on='full_date')#
#print(concat.head())

#initial = [kmodes.KModes(dummies,i) for i in range(1,10)]
#plt.plot([var for (cent,var) in initial])
#plt.show()

# Try shit with just the categorical variables and see what happens
# n_init is the number of times the algorithm will be run
# n_cluster is obviously the number of cluster i am looking for
# init sets the type of kmodes algorithm i am using
# verbose supresses the training information
# SETTING IT TO FOUR GAVE YOU SOME COOL RESULTS BEFORE
km = kmodes.KModes(n_clusters=10, init='Huang',  verbose=2)
clusters = km.fit_predict(categorical)
shit['clusters'] = clusters
#shit.to_csv('kmodes_clustering_2.csv')
clust_0 = len(shit[shit['clusters'] == 0])
clust_1 = len(shit[shit['clusters'] == 1])
clust_2 = len(shit[shit['clusters'] == 2])
clust_3 = len(shit[shit['clusters'] == 3])
clust_4 = len(shit[shit['clusters'] == 4])
clust_5 = len(shit[shit['clusters'] == 5])
clust_6 = len(shit[shit['clusters'] == 6])
clust_7 = len(shit[shit['clusters'] == 7])
clust_8 = len(shit[shit['clusters'] == 8])
clust_9 = len(shit[shit['clusters'] == 9])
#clust_10 = len(shit[shit['clusters'] == 10])

#n_clusters = 4

print(clust_0, clust_1, clust_2, clust_3, clust_4, clust_5, clust_6, clust_7, clust_8, clust_9)



#tsne = TSNE(n_components=2, verbose=1, perplexity=40, n_iter=250)
#tsne_results = tsne.fit_transform(dummies)


