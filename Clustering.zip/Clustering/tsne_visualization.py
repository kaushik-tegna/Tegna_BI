import umap
import pandas
import matplotlib.pyplot as plt
import mpld3
data = pandas.read_csv('spot_data.csv')
#REMOVE ADVERTISER
subset = data[['daypart']]
dayparts = subset['daypart'].tolist()
inventory_codes = subset['inventory_code'].tolist()
advertiser = subset['advertiser'].tolist()


#pair = list(zip(inventory_codes, advertiser, dayparts))









clusters = pandas.read_csv('kmodes_clustering_2.csv')
labels = clusters['clusters']
dummies = pandas.get_dummies(subset)
target = clusters['clusters'].values
cmap = plt.get_cmap('viridis')
#names = subset['advertiser'].unique().tolist()









# WE NEED TO COLOR BY DIFFERENT SHIT

# ARE MULTIPLE ADVERTISERS IN THE SAME GROUP
# MAYBE JUST CLUSTER BASED ON NOT EVERYTHING EVER HUH
# This gives cool results with clusters = 4
embedding = umap.UMAP( min_dist=0.1, n_neighbors=30, metric='jaccard').fit_transform(dummies, y=labels)

color_dict = { '0':'red', '1':'blue', '2':'black', '3':'green'}
# now i have to plot the shit
df = pandas.DataFrame(embedding, columns=('x', 'y'))
df['class'] = pandas.Series([str(x) for x in target], dtype="category")
fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
scatter = ax.scatter(x=list(df['x']), y=list(df['y']), c=[ color_dict[i] for i in df['class']], s=5)
tooltip = mpld3.plugins.PointLabelTooltip(scatter, labels=dayparts)
mpld3.plugins.connect(fig, tooltip)
mpld3.show()